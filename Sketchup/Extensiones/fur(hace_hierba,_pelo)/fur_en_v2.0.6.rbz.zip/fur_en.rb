#-------------------------------------------------------------------------------
#
# TAKUJI HATAKAWA(TAK2HATA)
# mr_penta[at]hotmail[dot]com
#
#-------------------------------------------------------------------------------

require 'sketchup.rb'
require 'extensions.rb'

#-------------------------------------------------------------------------------

module TAK2HATA
module T2H_FUR
  ### CONSTANTS ### ------------------------------------------------------------
  # Plugin information
  PLUGIN          = self
  PLUGIN_ID       = 'FUR_EN'
  PLUGIN_NAME     = 'FUR_EN'
  PLUGIN_VERSION  = '2.0.6'
  
  # Resource paths
  FILENAMESPACE = File.basename( __FILE__, '.rb' )
  PATH_ROOT     = File.dirname( __FILE__ )
  PATH          = "FUR_EN" ##File.join( PATH_ROOT, FILENAMESPACE )

  ### EXTENSION ### ------------------------------------------------------------
  
  ##unless file_loaded?( __FILE__ )
    loader = File.join( PATH, 'main.rb' )
    @ex = SketchupExtension.new( PLUGIN_NAME, loader )
    @ex.description = "Create Fur like grass and crowd.Last Update:2013.06.12"
    @ex.version     = PLUGIN_VERSION
    @ex.copyright   = 'TAKUJI HATAKWA 2011—2013'
    @ex.creator     = 'TAK2HATA (kurohoppie@gmail.com)'
    Sketchup.register_extension( @ex, true )
  ##end
end
end # module TAK2HATA

#-------------------------------------------------------------------------------

##file_loaded( __FILE__ )

#-------------------------------------------------------------------------------
file_loaded("fur_en.rb")


