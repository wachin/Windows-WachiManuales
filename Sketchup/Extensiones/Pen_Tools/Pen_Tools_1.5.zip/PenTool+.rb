=begin
  Copyright 2011 (c), TIG & Rich O'Brien
  All Rights Reserved.
  THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR IMPLIED 
  WARRANTIES,INCLUDING,WITHOUT LIMITATION,THE IMPLIED WARRANTIES OF 
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
###
  PenTool+.rb
###
Description:
	Similar to native Line Tool in use but has 7 primary features :-
	
	[1] Soft Draw allows the sketching of softened/smoothened lines
	[2] Hide Draw allows the sketching of hidden lines
	[3] Guide Draw allows the sketching of guide lines
	[4] Weld Draw allows the sketching of curves
    [5] Edge Draw allows the sketching of edges [lines] without making faces
	[6] Line Draw allows the sketching of edges with faces
	[7] Point Draw allows the sketching of construction points
###
Usage:
Run 'Pen Tool+.rb' from the 'Draw' menu or the 'Pen Tool+' toolbar.

Donations:
info@revitrev.org via Paypal

Versions:
	1.0 18/5/2011 - First Release
    1.1 18/5/2011 - Edge Draw added, glitches with typed in lengths corrected.
    1.2 18/5/2011 - Occasional glitch with ending a line-set by snapping to 
                    an existing edge fixed, drawing inside of groups/components 
                    addressed.
    1.3 18/5/2011 - Glitch with some welded lines fixed.
	1.4 22/5/2011 - Line Draw and Point Draw added.
	1.5 16/4/2012 - Guid Draw clash addressed
=end
#-----------------------------------------------------------------------------
require 'sketchup.rb'
#-----------------------------------------------------------------------------
class HLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
 
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","hlinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Hidden Line Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    #ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    
    Sketchup::set_status_text($exStrings.GetString("Hidden Line Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
  line=view.model.active_entities.add_line(p1,p2)
  if line
    if line.end.edges[1]
      ans=true
    else
      ans=false
    end
    drawn_lines=self.intersect(line)
    drawn_lines.each{|e|
    next if not e.valid?
	e.find_faces
    e.hidden=true
    }
    return ans
  else
    return false
  end#if
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
end

end # class HLineTool
#--------------------------------------------------------------------------
class SLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","slinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end### slinecursor.png MUST be in ../Plugins/Icons/ folder
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Soft Line Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else # create the line on the second click
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    #ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    
    Sketchup::set_status_text($exStrings.GetString("Soft Line Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
  line=view.model.active_entities.add_line(p1,p2)
  if line
    if line.end.edges[1]
      ans=true
    else
      ans=false
    end
    drawn_lines=self.intersect(line)
    drawn_lines.each{|e|
    next if not e.valid?
	e.find_faces
    e.smooth=true
    e.soft=true
    }
    return ans
  else
    return false
  end#if
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
end

end # class SLineTool
#--------------------------------------------------------------------------
class GLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","glinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Guide Line Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else # create the line on the second click
        if @ip2.valid?
            self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2)
    @state=1
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    
    Sketchup::set_status_text($exStrings.GetString("Guide Line Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def create_geometry(p1, p2, view)
  line=view.model.active_entities.add_cline(p1,p2)
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
	end
	
end # class GLineTool
#--------------------------------------------------------------------------
class WLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","wlinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    self.add_curve?()
	view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Weld Line Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    #ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    self.add_curve?()
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    self.add_curve?()
    @state=nil
    self.reset(view)
end

def add_curve?()
    if @lines and @lines[0]
      @lines.uniq!
      pts=[]
      @lines.each{|e|
        next if not e.valid?
        pts << e.vertices
      }
      pts.flatten!
      pts.uniq!
      pts << pts[0] if @lines.length==pts.length ### looped
      @lines[0].parent.entities.add_curve(pts)
    end#if
end

def reset(view)
    self.add_curve?() if not @state
    @lines=[] if not @state ###
	@state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds ###
    
    Sketchup::set_status_text($exStrings.GetString("Weld Line Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
    line=view.model.active_entities.add_line(p1,p2)
    if line
      if line.end.edges[1]
        ans=true
      else
        ans=false
      end
      drawn_lines=self.intersect(line)
      drawn_lines.each{|e|
        next if not e.valid?
	    e.find_faces
        @lines << e
      }
      return ans
    else
      return false
    end#if
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
end

end # class WLineTool
#--------------------------------------------------------------------------
class ELineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
 
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","elinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Edge Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    ##ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    
    Sketchup::set_status_text($exStrings.GetString("Edge Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
  line=view.model.active_entities.add_line(p1,p2)
  if line
    if line.end.edges[1]
      ans=true
    else
      ans=false
    end
    drawn_lines=self.intersect(line)
    drawn_lines.each{|e|
      next if not e.valid?
	  e.hidden=false
      e.smooth=false
      e.soft=false
    }
    return ans
  else
    return false
  end#if
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
end

end # class ELineTool
#--------------------------------------------------------------------------
class PLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

    def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","plinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end### slinecursor.png MUST be in ../Plugins/Icons/ folder
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Line Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else # create the line on the second click
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    #ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    
    Sketchup::set_status_text($exStrings.GetString("Line Tool: Pick start point"), SB_PROMPT) if @state==0 ###
    @ip1.clear if @state==0 ###
    @ip2.clear
    if view
        view.tooltip = nil
        view.invalidate if @drawn
    end
    @drawn = false
    @dragging = false
end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
  line=view.model.active_entities.add_line(p1,p2)
  if line
    if line.end.edges[1]
      ans=true
    else
      ans=false
    end
    drawn_lines=self.intersect(line)
    drawn_lines.each{|e|
    next if not e.valid?
	e.find_faces
    ###e.smooth=true
    ###e.soft=true
    }
    return ans
  else
    return false
  end#if
end

def draw_geometry(pt1, pt2, view)
    view.draw_line(pt1, pt2)
end

end # class PLineTool
#--------------------------------------------------------------------------
class CPLineTool

def initialize
    @ip = nil
    @ip1 = nil
    @ip2 = nil
    @xdown = 0
    @ydown = 0
    @cursor=nil
end

def getExtents
        case @state
          when 0 ### We are getting the first point
            @bb.add(@ip.position) if @ip && @ip.valid?
          else ### We are getting line ends...
            @bb.add(@ip.position) if @ip && @ip.valid?
            @bb.add(@ip1.position) if @ip1 && @ip1.valid?
            @bb.add(@ip2.position) if @ip2 && @ip2.valid?
        end
        @bb
    end

def activate
    @ip1 = Sketchup::InputPoint.new
    @ip2 = Sketchup::InputPoint.new
    @ip = Sketchup::InputPoint.new
    @drawn = false
    @state==nil ###
    if not @cursor ###
      path=File.join(File.dirname(__FILE__),"rob_hsltool","clinecursor.png")
	  @cursor=UI::create_cursor(path,0,30) if File.exist?(path)
    end### slinecursor.png MUST be in ../Plugins/Icons/ folder
    Sketchup::set_status_text($exStrings.GetString("Length"), SB_VCB_LABEL)
    self.reset(nil)
end

def deactivate(view)
    view.invalidate if @drawn
end

def onSetCursor()
	cursor=UI::set_cursor(@cursor) if @cursor
end

def onMouseMove(flags, x, y, view)
    if @state==0
        @ip.pick view, x, y
        if @ip != @ip1
            view.invalidate if @ip.display? or @ip1.display?
            @ip1.copy!(@ip)
            view.tooltip = @ip1.tooltip
        end
    else
        @ip2.pick(view, x, y, @ip1)
        view.tooltip = @ip2.tooltip if( @ip2.valid? )
        view.invalidate
        if @ip2.valid?
            length = @ip1.position.distance(@ip2.position)
            Sketchup::set_status_text(length.to_s, SB_VCB_VALUE)
        end
        if (x-@xdown).abs > 10 || (y-@ydown).abs > 10
            @dragging = true
        end
    end
end

def onLButtonDown(flags, x, y, view)
    if @state==0
        @ip1.pick view, x, y
        if @ip1.valid?
            @state = 1
            Sketchup::set_status_text($exStrings.GetString("Point Tool: Pick end point"), SB_PROMPT)
            @xdown = x
            @ydown = y
        end
    else # create the line on the second click
        if @ip2.valid?
            ph=view.pick_helper
            ph.do_pick(x,y)
            all=ph.all_picked
            all2s=all.to_s
            all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
            isend=self.create_geometry(@ip1.position, @ip2.position, view)
            @ip1.copy!(@ip2) ###
            @state=1
            @state=nil if all2s=~/#<Sketchup::Edge:/
            @state=nil if isend
            self.reset(view)
        end
    end
    
    view.lock_inference
end

def onLButtonUp(flags, x, y, view)
  if @dragging && @ip2.valid?
    ph=view.pick_helper
    ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnEdge or all[0].classify_point(@ip2.position)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(@ip1.position, @ip2.position,view)
    @ip1.copy!(@ip2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
  end
end

def onKeyDown(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY && repeat == 1 )
        @shift_down_time = Time.now
        
        if( view.inference_locked? )
            view.lock_inference
        elsif( @state == 0 && @ip1.valid? )
            view.lock_inference @ip1
        elsif( @state == 1 && @ip2.valid? )
            view.lock_inference @ip2, @ip1
        end
    end
end

def onKeyUp(key, repeat, flags, view)
    if( key == CONSTRAIN_MODIFIER_KEY &&
        view.inference_locked? &&
        (Time.now - @shift_down_time) > 0.5 )
        view.lock_inference
    end
end

def onUserText(text, view)
    return if not @state == 1
    return if not @ip2.valid?
    
    begin
        value = text.to_l
    rescue
        UI.beep
        puts "Cannot convert #{text} to a Length"
        value = nil
        Sketchup::set_status_text("", SB_VCB_VALUE)
    end
    return if !value

    pt1 = @ip1.position
    vec = @ip2.position - pt1
    if( vec.length == 0.0 )
        UI.beep
        return
    end
    vec.length = value
    pt2 = pt1 + vec
    
    ph=view.pick_helper
    #ph.do_pick(x,y)
    all=ph.all_picked
    all2s=all.to_s
    all2s="#<Sketchup::Edge:" if all[0].class==Sketchup::Face and (all[0].classify_point(pt2)==Sketchup::Face::PointOnEdge or all[0].classify_point(pt2)==Sketchup::Face::PointOnVertex)
    isend=self.create_geometry(pt1, pt2, view)
    @ip1=Sketchup::InputPoint.new(pt2) ###
    @state=1
    @state=nil if all2s=~/#<Sketchup::Edge:/
    @state=nil if isend
    self.reset(view)
    
end

def draw(view)
    if( @ip1.valid? )
        if( @ip1.display? )
            @ip1.draw(view)
            @drawn = true
        end
        
        if( @ip2.valid? )
            @ip2.draw(view) if( @ip2.display? )
            
            view.set_color_from_line(@ip1, @ip2)
            self.draw_geometry(@ip1.position, @ip2.position, view)
            @drawn = true
        end
    end
end

def onCancel(flag, view)
    @state=nil
    self.reset(view)
end

def onLButtonDoubleClick(flags, x, y, view)
    @state=nil
    self.reset(view)
end

def reset(view)
    @state=1
    ###@state = 0 if not @state ###
    @bb=Sketchup.active_model.bounds
    Sketchup::set_status_text($exStrings.GetString("Point Tool: Pick Point"), SB_PROMPT)
    ###@ip1.clear if @state==0 ###
    @ip2.clear
    if view
            view.tooltip = nil
            view.invalidate if @drawn
        end
        @drawn = false
        @dragging = false
    end

def intersect(edge=nil)
  return nil if not edge or edge.class!=Sketchup::Edge
  ents=edge.parent.entities
  tr=Geom::Transformation.new()
  exlines=[];ents.each{|e|exlines << e if e.class==Sketchup::Edge}
  ents.intersect_with(false,tr,ents,tr,true,[edge])
  crlines=[];ents.each{|e|crlines << e if e.class==Sketchup::Edge}
  return crlines-exlines+[edge]
end

def create_geometry(p1, p2, view)
    view.model.active_entities.add_cpoint(p2)
end

def draw_geometry(pt1, pt2, view)
    view.line_stipple="-.-"
	view.draw_line(pt1, pt2)
end

end # class CPLineTool
#--------------------------------------------------------------------------

### Shortcuts, Menu entries and Toolbar
def hlinetool()
    Sketchup.active_model.select_tool(HLineTool.new())
end
#--------------------------------------------------------------------------
def slinetool()
    Sketchup.active_model.select_tool(SLineTool.new())
end
#--------------------------------------------------------------------------
def glinetool()
    Sketchup.active_model.select_tool(GLineTool.new())
end
#--------------------------------------------------------------------------
def wlinetool()
    Sketchup.active_model.select_tool(WLineTool.new())
end
#--------------------------------------------------------------------------
def elinetool()
    Sketchup.active_model.select_tool(ELineTool.new())
end
#--------------------------------------------------------------------------
def plinetool()
    Sketchup.active_model.select_tool(PLineTool.new())
end
#--------------------------------------------------------------------------
def cplinetool()
    Sketchup.active_model.select_tool(CPLineTool.new())
end
#--------------------------------------------------------------------------

if not file_loaded?(File.basename(__FILE__))
	new_menu = UI.menu("Draw").add_submenu("Pen Tool +")	
	new_toolbar = UI::Toolbar.new("Pen Tool +")
	plugins = Sketchup.find_support_file("Plugins")	
	imgdir = File.join(plugins, "rob_hsltool")

	cmd = UI::Command.new("Soft Draw")  {Sketchup.active_model.select_tool(SLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "sline16x16.png")
	cmd.large_icon = File.join(imgdir, "sline24x24.png")
	cmd.tooltip = "Soft Draw"
	cmd.menu_text = "Soft Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)

	cmd = UI::Command.new("Hide Draw")  {Sketchup.active_model.select_tool(HLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "hline16x16.png")
	cmd.large_icon = File.join(imgdir, "hline24x24.png")
	cmd.tooltip = "Hide Draw"
	cmd.menu_text = "Hide Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)
	
	cmd = UI::Command.new("Guide Draw")  {Sketchup.active_model.select_tool(GLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "gline16x16.png")
	cmd.large_icon = File.join(imgdir, "gline24x24.png")
	cmd.tooltip = "Guide Draw"
	cmd.menu_text = "Guide Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)
	
	cmd = UI::Command.new("Weld Draw")  {Sketchup.active_model.select_tool(WLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "wline16x16.png")
	cmd.large_icon = File.join(imgdir, "wline24x24.png")
	cmd.tooltip = "Weld Draw"
	cmd.menu_text = "Weld Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)
	
	cmd = UI::Command.new("Edge Draw")  {Sketchup.active_model.select_tool(ELineTool.new())  }
	cmd.small_icon = File.join(imgdir, "eline16x16.png")
	cmd.large_icon = File.join(imgdir, "eline24x24.png")
	cmd.tooltip = "Edge Draw"
	cmd.menu_text = "Edge Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)
	
	cmd = UI::Command.new("Line Draw")  {Sketchup.active_model.select_tool(PLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "pline16x16.png")
	cmd.large_icon = File.join(imgdir, "pline24x24.png")
	cmd.tooltip = "Line Draw"
	cmd.menu_text = "Line Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)
	
	cmd = UI::Command.new("Point Draw")  {Sketchup.active_model.select_tool(CPLineTool.new())  }
	cmd.small_icon = File.join(imgdir, "cline16x16.png")
	cmd.large_icon = File.join(imgdir, "cline24x24.png")
	cmd.tooltip = "Point Draw"
	cmd.menu_text = "Point Draw"
	
    new_menu.add_item(cmd)
    new_toolbar.add_item(cmd)

	###new_toolbar.show ### ONLY show if was visible before...
    new_toolbar.restore if new_toolbar.get_last_state==TB_VISIBLE
    
end
#--------------------------------------------------------------------------
file_loaded(File.basename(__FILE__))