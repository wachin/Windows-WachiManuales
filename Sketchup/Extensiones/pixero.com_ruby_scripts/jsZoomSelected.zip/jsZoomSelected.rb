# Copyright 2007, Jan Sandstrom

# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

# Name :          jsZoomSelected.rb 1.0
# Description :   Zooms to selected object
# Author :         Jan Sandstrom
# Date :           17.Feb.2007
# History:        1.0 (17.Feb.2007) - first version

require 'sketchup.rb'

def jsZoomSelected
	model = Sketchup.active_model
	entities = model.active_entities
	sel = model.selection

	if sel.empty?
     		UI.beep
     		UI.messagebox("Nothing Selected!")
     		return nil
  	end#if
  	
  	Sketchup.send_action("viewZoomToSelection:")
  	
	
end

if (not file_loaded?("jsZoomSelected.rb"))
    UI.menu("Plugins").add_separator
    UI.menu("Plugins").add_item("JS Zoom Selected ") { jsZoomSelected }
end
file_loaded("jsZoomSelected.rb")

