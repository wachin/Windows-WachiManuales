# Name: 	jsCameraTool
# Author: 	Jan Sandstrom   www.pixero.com
# Description: 	Rotate and position the camera numericly.	

require 'sketchup.rb'

def jsCameraTool

	model = Sketchup.active_model
	view = model.active_view
	camera = view.camera
	eye = camera.eye
	target = camera.target
	up = camera.up
	direction = camera.direction

	# Dialog
  @useWorldUp = "On" if not defined? @useWorldUp
  @pan = 0 if not defined? @pan
  @tilt = 0 if not defined? @tilt
  @roll = 0 if not defined? @roll
  @posX = 0 if not defined? @posX
  @posY = 0 if not defined? @posY	
  @posZ = 0 if not defined? @posZ		
  
  enums = ["On" '|' "Off", "", "", "", "", "", ""]
	prompts = ["Use World Up", "Pan           (degree)", "Tilt            (degree)", "Roll           (degree)", "Dolly         (in/out) ", "Truck         (left/right) ", "Pedestal   (up/down) "]
  values = [@useWorldUp, @pan, @tilt, @roll, @posZ, @posX, @posY]
	results = inputbox(prompts, values, enums, "JS CameraTool")
	useWorldUp, pan, tilt, roll, posZ, posX, posY = results
	@useWorldUp, @pan, @tilt, @roll, @posZ, @posX, @posY = useWorldUp, pan, tilt, roll, posZ, posX, posY

  pan = pan.to_f
	tilt = tilt.to_f
	roll = roll.to_f
  
	panAxis = camera.yaxis 	        #pan
	tiltAxis = direction * Z_AXIS 		#tilt
	rollAxis = direction 			          #roll
  
  xaxis = camera.xaxis
  yaxis = camera.yaxis
  zaxis = camera.zaxis
  
  worldUp = Geom::Vector3d.new (0, 0, 1) 
  
  if (useWorldUp == "On")
    panAxis = worldUp
    yaxis = worldUp
  end
  
  case Sketchup.active_model.options["UnitsOptions"]["LengthUnit"]
		when 0
			posX = posX.to_f.inch
			posY = posY.to_f.inch
			posZ = posZ.to_f.inch
		when 1
			posX = posX.to_f.feet
			posY = posY.to_f.feet
			posZ = posZ.to_f.feet
		when 2
			posX = posX.to_f.mm
			posY = posY.to_f.mm
			posZ = posZ.to_f.mm
		when 3
			posX = posX.to_f.cm
			posY = posY.to_f.cm
			posZ = posZ.to_f.cm
		when 4
			posX = posX.to_f.m
			posY = posY.to_f.m
			posZ = posZ.to_f.m
end	

### Rotation
	tp = Geom::Transformation.rotation(eye, panAxis, pan*(Math::PI/180))
	tt = Geom::Transformation.rotation(eye, tiltAxis, tilt*(Math::PI/180))
	tr = Geom::Transformation.rotation(eye, rollAxis, roll*(Math::PI/180))

	target.transform! tp
	target.transform! tt
	target.transform! tr
	up.transform! tt
	up.transform! tr
  

### Translation
newEye = eye.offset(xaxis, posX)
newEye = newEye.offset(yaxis, posY)
newEye = newEye.offset(zaxis, posZ)

newTarget = target.offset(xaxis, posX)
newTarget = newTarget.offset(yaxis, posY)
newTarget = newTarget.offset(zaxis, posZ)

eye = newEye
target = newTarget

camera = camera.set(eye, target, up)
  
end #def jsCameraTool

if( not file_loaded?("jsCameraTool.rb") )
    UI.menu("Plugins").add_item("JS CameraTool") { jsCameraTool }
end

