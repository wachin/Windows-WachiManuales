
#  Name : jsFocalLength
#  Description : Set the Faocal length of the camera
#  Author : Jan Sandstrom (www.pixero.com) 
#  Date : 5 February 2008



require 'sketchup.rb'


def jsFocalLength

	model = Sketchup.active_model
	view = model.active_view
	camera = view.camera
	


	@fl = camera.focal_length if not defined? @fl

	prompts = ["Focal length: "]
	values = [@fl]
	results = inputbox (prompts, values, "Focal length Settings")
	fl = results[0]
	@fl = fl


	camera.focal_length = @fl

end 

############################################################
if( not file_loaded?("jsFocalLength.rb") )
    UI.menu("Camera").add_separator
    UI.menu("Camera").add_item("JS Focal Length") { jsFocalLength  }
end

file_loaded("jsFocalLength.rb")
