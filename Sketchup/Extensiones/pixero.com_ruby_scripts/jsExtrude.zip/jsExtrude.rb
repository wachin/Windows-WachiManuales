#  Name : JS Extrude
#  Description : Extrudes a face/faces along either X, Y or Z axis or the normal direction.
#  Author : Jan Sandstrom (www.pixero.com) based on the Push Pull Z script by Didier Bur
#  Usage : Select a face, select JS Extrude from the Plugins menu, choose direction, enter distance and here you go
#  Date : 28 July 2007


require 'sketchup.rb'




def jsExtrude

  model = Sketchup.active_model 
  model.start_operation "jsExtrude"
  entities = model.active_entities
  ss = model.selection

  if ss.empty? 
    UI.messagebox("Nothing selected!")
    return nil
    end 

  a_face_is_selected = false ;    # assume the user did not select any faces 
  ss.each {|e|                # "e" is an abbreviation for the term "element", since we are 
                              # iterating through all the elements in the array. 
    a_face_is_selected = true if (e.is_a? Sketchup::Face)  # If any face is selected, we're good to go. 
    } 

# If the user did not select any faces, present an error message and exit 

  if (not a_face_is_selected) then 
    UI.messagebox("No faces were selected.\nPlease select face(s) and rerun.")
    return nil
    end


  pts2 = []      # Create a fresh array 
  newlines = []  # Create a fresh array 
	

	### Dialog

		@direction = "Z" if not @direction
		@distance = 1000.mm if not defined? @distance  and model.options["UnitsOptions"]["LengthUnit"]>1
	

	enums = ["X" '|' "Y" '|' "Z" '|' "Normal"]
	prompts = ["Direction: ", "Distance:"]   # Distance can be either a positive or negative value
	values = [@direction, @distance]
	results = inputbox (prompts, values, enums, "Extrude Settings")
	#return nil if not results
	direction, distance = results
	@direction, @distance = direction, distance
 
 
 	if (@direction != "Normal")
 
 		if (@direction == "X")
			adjuster = [distance, 0, 0];
		end#if
		if (@direction == "Y")
			adjuster = [0, distance, 0];
		end#if
		if (@direction == "Z")
			adjuster = [0, 0, distance];
		end#if
 
 		# Process each face: 

  	ss.each {|f| 
    	next if not (f.is_a? Sketchup::Face)   # Ignore items in the selection that are not faces. 
   
    	next if  (@direction == "X") and f.normal.x == 0  # Ignore faces that can't be extruded in that direction
    	next if  (@direction == "Y") and f.normal.y == 0  # Ignore faces that can't be extruded in that direction
    	next if  (@direction == "Z") and f.normal.z == 0  # Ignore faces that can't be extruded in that direction
    	pts2.clear 
    	newlines.clear  # empty out the array 

  		# copy the selected face

    	f.vertices.each {|p| 
      	pts2 << p.position + adjuster                          
      	newlines << entities.add_line([p.position,pts2.last])  # Add the vertical line while we're here 
      	}
    	face_copy = entities.add_face pts2                       # Add the new top face 

    	newlines.each {|nl|     # fill in side faces too  
      	if nl.valid? then nl.find_faces end ; 
      	} 
    	}    #end of ss.each 
	end # if (@direction != "Normal")
	
	if (@direction == "Normal")
			ss.each {|f| 
				next if not (f.is_a? Sketchup::Face)   # Ignore items in the selection that are not faces. 
				f.pushpull Float(distance), true; 	
			}
	end
	


  model.commit_operation
  end    # of def


if( not file_loaded?("jsExtrude.rb") )
  add_separator_to_menu("Plugins")
  UI.menu("Plugins").add_item("JS Extrude") { jsExtrude }
  end

#-----------------------------------------------------------------------------
file_loaded("jsExtrude.rb")
