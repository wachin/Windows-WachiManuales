
#  Name : JS Shadow Control<
#  Description : Sets shadow on or off
#  Author : Jan Sandstrom (www.pixero.com)
#  Date : 14 Aug 2007

require 'sketchup.rb'

def jsShadowControl

  model = Sketchup.active_model 
  entities = model.active_entities
  if (entities.kind_of? Sketchup::Group) or (entities.kind_of? Sketchup::ComponentInstance) 
      entities = group.entities
  end
  ss = model.selection

if ss.empty? 
    UI.messagebox("Nothing selected!")
    return nil
end 
  
  # Dialog
	@cast = "On" if not @cast
	@receive = "On" if not @receive


	enums = ["On" '|' "Off", "On" '|' "Off"]
	prompts = ["Cast shadows: ", "Receive shadows: "]
	values = [@cast, @receive]
	results = inputbox(prompts, values, enums, "Shadow Control")
	cast, receive = results
	@cast, @receive = cast, receive
	

	   ss.each {|e| 
		if(@cast == "On")	
			e.casts_shadows= true
		end #if
		if(@cast == "Off")
			e.casts_shadows= false
		end #if
		
		if(@receive == "On")	
			e.receives_shadows= true
		end #if
		if(@receive == "Off")
			e.receives_shadows= false
		end #if
	} #end of ss.each 

end #jsShadowControl

if( not file_loaded?("jsShadowControl.rb") )
    UI.menu("Plugins").add_separator
    UI.menu("Plugins").add_item("JS Shadow Control") { jsShadowControl  }
end

file_loaded("jsShadowControl.rb")