# Name: 	jsFrameStep
# Author: 	Jan Sandstrom   www.pixero.com
# Description:	Shows a specified frame of an animation
# Date: 	15 september 2007

require 'sketchup.rb'


def jsFrameStep
	model = Sketchup.active_model
	pages = model.pages
	
	@fps = 25 if not defined? @fps
	@frame = 1 if not defined? @frame
	prompts = ["Frames per second:","Go to frame:"]
	values = [@fps,@frame]
	results = inputbox(prompts, values, "Frame Step")
	fps,frame = results
	@fps, @frame = fps, frame

	fps = fps.to_i 
	frame = frame.to_f
	
 
	thisFrame = frame/fps
	frameNumber = frame
	
	#puts frameNumber
	#puts thisFrame
	status = pages.show_frame_at  thisFrame

end #def JS_FrameStep

if( not file_loaded?("jsFrameStep.rb") )
    UI.menu("Plugins").add_item("JS Frame Step") { jsFrameStep  }
end

file_loaded("jsFrameStep.rb")
