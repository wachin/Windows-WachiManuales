
#  Name : JS BackgroundColor
#  Description : Set the Background or Sky colors
#  Author : Jan Sandstrom (www.pixero.com) 
# Usage: Use sky color for backround color
#  Date : 3 September 2007
# Added GroundColor settings: 8 January 2008


require 'sketchup.rb'


def jsBackgroundColor

	model = Sketchup.active_model
	view = model.active_view
	width = view.vpwidth
	height = view.vpheight


	### Dialog

	@background = "Sky" if not @background

	@br = 255 if not defined? @br
	@bg = 255 if not defined? @bg
	@bb = 255 if not defined? @bb
  
  @sr = 162 if not defined? @sr
	@sg = 196 if not defined? @sg
	@sb = 220 if not defined? @sb

	@hr = 255 if not defined? @hr
	@hg = 255 if not defined? @hg
	@hb = 255 if not defined? @hb

	@gro = "Off" if not @gro
  
  @gr = 210 if not defined? @gr
  @gg = 208 if not defined? @gg
  @gb = 185 if not defined? @gb
	
	enums =["Sky" '|' "Background", "", "", "", "", "", "", "", "", "", "Off" '|' "On", "", "", "" ]
	prompts =["Background: ", "Backgr R: ", "Backgr G: ", "Backgr B: ", "Sky R: ", "Sky G: ", "Sky B: ", "Horizon R: ", "Horizon G: ", "Horizon B: ", "Ground: ", "Ground R: ",  "Ground G: ", "Ground B: "]
	values =[@background, @br, @bg, @bb, @sr, @sg, @sb, @hr, @hg, @hb, @gro,@gr,@gg,@gb]
	results = inputbox (prompts, values, enums, "Background Settings")
	background, br, bg, bb, sr, sg, sb, hr, hg, hb, gro, gr, gg, gb = results
	@background, @br, @bg, @bb, @sr, @sg, @sb, @hr, @hg, @hb, @gro, @gr, @gg, @gb = background, br, bg, bb, sr, sg, sb, hr, hg, hb, gro, gr, gg, gb

	bkgrColor = Sketchup::Color.new(br, bg, bb, 255)
	skyColor = Sketchup::Color.new(sr, sg, sb, 255)
	horizonColor = Sketchup::Color.new(hr, hg, hb, 255)
	groColor = Sketchup::Color.new(gr, gg, gb, 255)

	if(background == "Background" && gro == "On")
		model.rendering_options["DrawHorizon"] = false
		model.rendering_options["BackgroundColor"] = bkgrColor
    model.rendering_options["DrawGround"] = true
    model.rendering_options["GroundColor"] = groColor
  end
  if(background == "Background" && gro == "Off")
		model.rendering_options["DrawHorizon"] = false
		model.rendering_options["BackgroundColor"] = bkgrColor
    model.rendering_options["DrawGround"] = false
  end
	if(background == "Sky" && gro == "On")
		model.rendering_options["DrawHorizon"] = true
		model.rendering_options["SkyColor"] = skyColor
		model.rendering_options["HorizonColor"] = horizonColor
    model.rendering_options["DrawGround"] = true
    model.rendering_options["GroundColor"] = groColor
  end
	if(background == "Sky" && gro == "Off")
		model.rendering_options["DrawHorizon"] = true
		model.rendering_options["SkyColor"] = skyColor
		model.rendering_options["HorizonColor"] = horizonColor
    model.rendering_options["DrawGround"] = false
	end #if



end    # of def

if( not file_loaded?("jsBackgroundColor.rb") )
#  add_separator_to_menu("Plugins")
  UI.menu("Plugins").add_item("JS BackgroundColor") { jsBackgroundColor }
  end
