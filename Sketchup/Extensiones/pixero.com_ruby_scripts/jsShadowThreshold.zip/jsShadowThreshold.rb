
#  Name : JS Shadow Threshold
#  Description : Sets cast shadow with a threshold
#  Author : Jan Sandstrom (www.pixero.com)
#  Date : 12 Aug 2007
#  Thanks to Todd Burch and TIG.

require 'sketchup.rb'

def jsShadowThreshold

  model = Sketchup.active_model 
  entities = model.active_entities
  if (entities.kind_of? Sketchup::Group) or (entities.kind_of? Sketchup::ComponentInstance) 
      entities = group.entities
  end
  ss = model.selection
  
  # Dialog
	@setfor = "Selection" if not @setfor
	@thresh = 0.7 if not @thresh

	enums = ["Entire model" '|' "Selection", ""]
	prompts = ["Set shadow for: ", "Shadow threshold: "]
	values = [@setfor, @thresh]
	results = inputbox(prompts, values, enums, "Shadow threshold")
	setfor, thresh = results
	@setfor, @thresh = setfor, thresh
	
	if (@setfor == "Entire model")
	  entities.each {|e|
		 if (e.material == nil)
		UI.messagebox("No material assigned!")
                            return nil
                   end #if
		alpha = e.material.alpha   #Must have a material assigned
		
		if (alpha < thresh) 
			e.casts_shadows= false
		else
			e.casts_shadows= true
		end #if
	} #end of entities.each 
	end #if

	if(@setfor == "Selection")
	     if ss.empty? 
    	        UI.messagebox("Nothing selected!")
    	        return nil
  	     end 
	   ss.each {|e| 

                   if (e.material == nil)
		UI.messagebox("No material assigned!")
                            return nil
                   end #if
		alpha = e.material.alpha   #Must have a material assigned
		
		if (alpha < thresh) 
			e.casts_shadows= false
		else
			e.casts_shadows= true
		end #if
	} #end of ss.each 
   end #if
end #jsShadowThreshold

if( not file_loaded?("jsShadowThreshold.rb") )
    UI.menu("Plugins").add_separator
    UI.menu("Plugins").add_item("JS Shadow Threshold") { jsShadowThreshold  }
end

file_loaded("jsShadowThreshold.rb")